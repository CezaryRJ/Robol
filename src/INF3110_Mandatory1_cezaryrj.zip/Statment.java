
abstract class Statment implements Robol{
public abstract void Interpret();
}
