
public class Grid {
	Number x;
	Number y;

	public void size(Number x, Number y) {
		this.x = x;
		this.y = y;

	}

	
}
