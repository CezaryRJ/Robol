
public interface Robol {
	void Interpret();

}
