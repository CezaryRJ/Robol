
public class Program implements Robol {
	Grid grid;
	Robot robot;

	public Program(Grid grid, Robot robot) {
		this.grid = grid;
		this.robot = robot;
	}

	public void Interpret() {

		robot.Interpret();
	}
}
